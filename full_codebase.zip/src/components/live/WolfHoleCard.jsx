import { useMemo } from "react";

const sc = {
  green:      "#1a5c35",
  greenLight: "#f0f7f3",
  gold:       "#b8952a",
  ink:        "#1a1a1a",
  muted:      "#6b7280",
  border:     "#d1d5db",
  red:        "#b3261e",
  redLight:   "#fef2f2",
  accent:     "#0a5cff",
  accentLight:"#eaf1ff",
};

const HAMMER_QUICK = [2, 4];
const HAMMER_MORE = [8, 16, 32];

const DEFAULT_WOLF_HOLE_CONFIG = {
  partnerId: null,
  loneWolfDeclared: false,   // declared solo right after own tee shot, before watching others
  blindWolfDeclared: false,  // declared solo before even own tee shot
  shucked: false,
  hammerMultiplier: 1,
  hammerResolution: "played_out", // "played_out" | "rejected"
  concededBy: null,               // "small" | "big" — only set if rejected
  showMoreHammer: false,
  confirmed: false, // true once ANY real Wolf decision was made for this hole — the light hard block checks this before allowing save
};

export function getWolfHoleConfig(wolfHoles, hole) {
  return { ...DEFAULT_WOLF_HOLE_CONFIG, ...(wolfHoles?.[hole] || {}) };
}

/**
 * Light hard block (Tim's call, July 2026): a Wolf hole can't save until
 * SOMETHING was explicitly decided — a partner, Lone/Blind Wolf, or the
 * explicit "Wolf plays alone" confirm button. Distinguishes "confirmed
 * solo is correct" from "nobody looked at this hole at all," since Pack
 * Wolf is the common case (~90%) and an untouched default silently
 * defaulting to solo would usually be wrong, not just occasionally.
 */
export function isWolfHoleConfirmed(wolfHoles, hole) {
  return !!getWolfHoleConfig(wolfHoles, hole).confirmed;
}

/**
 * Derives the Wolf format for a hole from its raw config.
 * Format keys match the engine exactly: "pack" | "solo" | "loneWolf" | "blindWolf" | "shuck".
 * Priority: Blind Wolf > Lone Wolf > Shuck > Pack > Solo (default).
 */
export function getWolfFormat(config) {
  if (config.blindWolfDeclared) return "blindWolf";
  if (config.loneWolfDeclared) return "loneWolf";
  if (config.shucked) return "shuck";
  if (config.partnerId) return "pack";
  return "solo";
}

export default function WolfHoleCard({
  currentHole,
  players = [],          // rotation-order active players (5)
  wolfHoles = {},         // { [hole]: config }
  onUpdateWolfHole,       // (hole, updates) => void
  hammerEnabled = false,
  isSuperWolf = false,
  overrideWolfId = null,       // Super Wolf: who's actually Wolf this hole (from standings, not rotation)
  rankedStandings = null,      // Super Wolf: [{playerId, standing}, ...] worst to best
  superWolfBetAmount = null,   // Super Wolf: this hole's free-form bet amount
  onChangeSuperWolfBetAmount,  // Super Wolf: (hole, amount) => void
}) {
  const wolfIndex = useMemo(() => {
    if (!players.length) return 0;
    return (currentHole - 1) % players.length;
  }, [currentHole, players.length]);

  const wolf = isSuperWolf
    ? (overrideWolfId ? players.find((p) => p.id === overrideWolfId) : null)
    : players[wolfIndex];
  const others = wolf ? players.filter((p) => p.id !== wolf.id) : players;
  const config = getWolfHoleConfig(wolfHoles, currentHole);
  const format = getWolfFormat(config);
  const declaredSolo = config.loneWolfDeclared || config.blindWolfDeclared;

  if (players.length !== 5) {
    return (
      <div style={{ background: sc.redLight, border: `1px solid ${sc.red}`, borderRadius: 12, padding: 14, marginBottom: 12, fontSize: 13, color: sc.red }}>
        Wolf needs exactly 5 active players to show hole details.
      </div>
    );
  }
  if (!wolf) {
    return (
      <div style={{ background: "#fffbeb", border: "1px solid #fcd34d", borderRadius: 12, padding: 14, marginBottom: 12, fontSize: 13, color: "#92400e" }}>
        Can't assign Super Wolf yet — finish scoring holes 1-15 first so there's a standing to rank.
      </div>
    );
  }

  const update = (updates) => onUpdateWolfHole(currentHole, updates);
  const partner = config.partnerId ? players.find((p) => p.id === config.partnerId) : null;
  const nameOf = (id) => players.find((p) => p.id === id)?.name || id;

  const declareButton = (key, label, sublabel) => {
    const active = config[key];
    return (
      <button
        onClick={() => update(
          active
            ? { [key]: false, confirmed: false }
            : {
                loneWolfDeclared: false,
                blindWolfDeclared: false,
                [key]: true,
                partnerId: null,
                shucked: false,
                confirmed: true,
              }
        )}
        style={{
          padding: "8px 6px", fontSize: 12, fontWeight: 600, fontFamily: "inherit", cursor: "pointer",
          borderRadius: 8, textAlign: "center",
          border: active ? `1px solid ${sc.accent}` : `1px dashed ${sc.border}`,
          background: active ? sc.accentLight : "#fafafa",
          color: active ? sc.accent : sc.muted,
        }}
      >
        {active ? `✓ ${label}` : label}
        <div style={{ fontSize: 9, fontWeight: active ? 700 : 400, marginTop: 1 }}>
          {active ? "tap to undo" : sublabel}
        </div>
      </button>
    );
  };

  return (
    <div style={{ background: "#fff", border: `1px solid ${sc.border}`, borderRadius: 12, padding: 14, marginBottom: 12 }}>
      {isSuperWolf && (
        <div style={{ background: sc.redLight, border: `1px solid ${sc.red}`, borderRadius: 8, padding: 10, marginBottom: 12 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: sc.red, marginBottom: 6, textTransform: "uppercase", letterSpacing: 0.5 }}>
            Super Wolf — standings before this hole
          </div>
          {rankedStandings && rankedStandings.length > 0 && (
            <div style={{ marginBottom: 10 }}>
              {rankedStandings.map((r, i) => (
                <div key={r.playerId} style={{ display: "flex", justifyContent: "space-between", fontSize: 12, padding: "2px 0", fontWeight: i === 0 ? 700 : 400 }}>
                  <span style={{ color: sc.ink }}>{i === 0 ? "🐺 " : ""}{nameOf(r.playerId)}</span>
                  <span style={{ color: r.standing < 0 ? sc.red : r.standing > 0 ? sc.green : sc.muted }}>
                    {r.standing < 0 ? `-$${Math.abs(r.standing).toFixed(2)}` : r.standing > 0 ? `+$${r.standing.toFixed(2)}` : "$0.00"}
                  </span>
                </div>
              ))}
            </div>
          )}
          <label style={{ display: "block", fontSize: 12, color: sc.ink, marginBottom: 4 }}>
            Dollar value for this hole
          </label>
          <input
            type="number"
            min="0"
            step="1"
            value={superWolfBetAmount ?? ""}
            onChange={(e) => onChangeSuperWolfBetAmount?.(currentHole, e.target.value)}
            placeholder="e.g. 25"
            style={{
              width: "100%", padding: "8px 10px", fontSize: 15, fontFamily: "inherit",
              border: `1px solid ${sc.border}`, borderRadius: 8,
            }}
          />
        </div>
      )}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 10 }}>
        <div style={{ fontSize: 15, fontWeight: 700, color: sc.ink }}>Hole {currentHole} — Wolf</div>
        <div style={{ fontSize: 14, fontWeight: 600, color: sc.green }}>{wolf.name}</div>
      </div>

      {/* Declare solo — two distinct tiers, based on WHEN it's declared */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginBottom: 12 }}>
        {declareButton("loneWolfDeclared", "Lone Wolf", "after own shot")}
        {declareButton("blindWolfDeclared", "Blind Wolf", "before own shot")}
      </div>

      {!declaredSolo && (
        <>
          <div style={{ fontSize: 12, color: sc.muted, marginBottom: 6 }}>Partner</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 6, marginBottom: 6 }}>
            {others.map((p) => {
              const selected = config.partnerId === p.id;
              return (
                <button
                  key={p.id}
                  onClick={() => update({ partnerId: selected ? null : p.id, shucked: false, confirmed: true })}
                  style={{
                    padding: "10px 0", fontSize: 13, fontWeight: selected ? 600 : 400,
                    borderRadius: 8, cursor: "pointer", fontFamily: "inherit",
                    border: selected ? `1.5px solid ${sc.accent}` : `1px solid ${sc.border}`,
                    background: selected ? sc.accentLight : "#fff",
                    color: selected ? sc.accent : sc.ink,
                  }}
                >
                  {p.name}
                </button>
              );
            })}
          </div>

          {!config.partnerId && (
            <button
              onClick={() => update({ confirmed: true })}
              style={{
                width: "100%", padding: "9px 0", fontSize: 12, fontWeight: 600, fontFamily: "inherit", cursor: "pointer",
                borderRadius: 8, marginBottom: 10, textAlign: "center",
                border: config.confirmed ? `1px solid ${sc.accent}` : `1px dashed ${sc.border}`,
                background: config.confirmed ? sc.accentLight : "#fafafa",
                color: config.confirmed ? sc.accent : sc.muted,
              }}
            >
              {config.confirmed ? "✓ Confirmed — Wolf plays alone" : "No partner — confirm Wolf plays alone"}
            </button>
          )}

          {config.partnerId && (
            <div
              onClick={() => update({ shucked: !config.shucked, confirmed: true })}
              style={{
                display: "flex", alignItems: "center", justifyContent: "space-between",
                background: config.shucked ? sc.redLight : "#fafafa",
                borderRadius: 8, padding: "8px 12px", marginBottom: 12, cursor: "pointer",
              }}
            >
              <span style={{ fontSize: 13, color: config.shucked ? sc.red : sc.muted, fontWeight: config.shucked ? 600 : 400 }}>
                {partner?.name} shucked
              </span>
              <div
                style={{
                  width: 40, height: 24, borderRadius: 12, position: "relative",
                  background: config.shucked ? sc.red : "#d1d5db",
                }}
              >
                <span style={{
                  position: "absolute", top: 2, width: 18, height: 18, borderRadius: "50%", background: "#fff",
                  left: config.shucked ? 18 : 2, transition: "left 0.15s",
                }} />
              </div>
            </div>
          )}
        </>
      )}

      {/* Format summary — tier name only, no multiplier shown here since
          the actual $ multiplier depends on Wolf Style (Harrison vs.
          Classic), which is a Setup-level choice, not per-hole. */}
      <div style={{ fontSize: 11, color: sc.muted, marginBottom: hammerEnabled ? 12 : 0, paddingTop: 8, borderTop: `1px solid ${sc.border}` }}>
        {format === "blindWolf" && `${wolf.name} — Blind Wolf · 1v4`}
        {format === "loneWolf" && `${wolf.name} — Lone Wolf · 1v4`}
        {format === "shuck" && `${partner?.name || "Partner"} shucked · playing alone vs. everyone else`}
        {format === "pack" && partner && `Pack Wolf · ${wolf.name} + ${partner.name} vs. the other 3`}
        {format === "solo" && `${wolf.name} — Wolf · 1v4`}
      </div>

      {/* Hammer entry */}
      {hammerEnabled && (
        <div>
          <div style={{ fontSize: 12, color: sc.muted, marginBottom: 6 }}>Hammer</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 6, marginBottom: config.hammerMultiplier > 1 ? 10 : 0 }}>
            {HAMMER_QUICK.map((m) => (
              <button
                key={m}
                onClick={() => update({ hammerMultiplier: config.hammerMultiplier === m ? 1 : m, showMoreHammer: false })}
                style={{
                  padding: "10px 0", fontSize: 13, fontWeight: config.hammerMultiplier === m ? 600 : 400,
                  borderRadius: 8, cursor: "pointer", fontFamily: "inherit",
                  border: config.hammerMultiplier === m ? `1.5px solid ${sc.accent}` : `1px solid ${sc.border}`,
                  background: config.hammerMultiplier === m ? sc.accentLight : "#fff",
                  color: config.hammerMultiplier === m ? sc.accent : sc.ink,
                }}
              >
                {m}x
              </button>
            ))}
            <button
              onClick={() => update({ showMoreHammer: !config.showMoreHammer })}
              style={{
                padding: "10px 0", fontSize: 13, borderRadius: 8, cursor: "pointer", fontFamily: "inherit",
                border: HAMMER_MORE.includes(config.hammerMultiplier) ? `1.5px solid ${sc.accent}` : `1px solid ${sc.border}`,
                background: HAMMER_MORE.includes(config.hammerMultiplier) ? sc.accentLight : "#fff",
                color: HAMMER_MORE.includes(config.hammerMultiplier) ? sc.accent : sc.ink,
              }}
            >
              {HAMMER_MORE.includes(config.hammerMultiplier) ? `${config.hammerMultiplier}x` : "More"}
            </button>
          </div>

          {config.showMoreHammer && (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 6, marginBottom: 10 }}>
              {HAMMER_MORE.map((m) => (
                <button
                  key={m}
                  onClick={() => update({ hammerMultiplier: m, showMoreHammer: false })}
                  style={{
                    padding: "8px 0", fontSize: 12, borderRadius: 8, cursor: "pointer", fontFamily: "inherit",
                    border: config.hammerMultiplier === m ? `1.5px solid ${sc.accent}` : `1px solid ${sc.border}`,
                    background: config.hammerMultiplier === m ? sc.accentLight : "#fff",
                    color: config.hammerMultiplier === m ? sc.accent : sc.ink,
                  }}
                >
                  {m}x
                </button>
              ))}
            </div>
          )}

          {config.hammerMultiplier > 1 && (
            <div style={{ borderTop: `1px solid ${sc.border}`, paddingTop: 10 }}>
              <div style={{ fontSize: 12, color: sc.muted, marginBottom: 6 }}>How did it end?</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 6 }}>
                <button
                  onClick={() => update({ hammerResolution: "played_out", concededBy: null })}
                  style={{
                    padding: "9px 0", fontSize: 12, fontWeight: config.hammerResolution === "played_out" ? 600 : 400,
                    borderRadius: 8, cursor: "pointer", fontFamily: "inherit",
                    border: config.hammerResolution === "played_out" ? `1.5px solid ${sc.accent}` : `1px solid ${sc.border}`,
                    background: config.hammerResolution === "played_out" ? sc.accentLight : "#fff",
                    color: config.hammerResolution === "played_out" ? sc.accent : sc.ink,
                  }}
                >
                  Played out
                </button>
                <button
                  onClick={() => update({ hammerResolution: "rejected" })}
                  style={{
                    padding: "9px 0", fontSize: 12, fontWeight: config.hammerResolution === "rejected" ? 600 : 400,
                    borderRadius: 8, cursor: "pointer", fontFamily: "inherit",
                    border: config.hammerResolution === "rejected" ? `1.5px solid ${sc.red}` : `1px solid ${sc.border}`,
                    background: config.hammerResolution === "rejected" ? sc.redLight : "#fff",
                    color: config.hammerResolution === "rejected" ? sc.red : sc.ink,
                  }}
                >
                  Rejected
                </button>
              </div>

              {config.hammerResolution === "rejected" && (
                <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 6, marginTop: 8 }}>
                  <button
                    onClick={() => update({ concededBy: "small" })}
                    style={{
                      padding: "8px 0", fontSize: 12, borderRadius: 8, cursor: "pointer", fontFamily: "inherit",
                      border: config.concededBy === "small" ? `1.5px solid ${sc.red}` : `1px solid ${sc.border}`,
                      background: config.concededBy === "small" ? sc.redLight : "#fff",
                      color: config.concededBy === "small" ? sc.red : sc.ink,
                    }}
                  >
                    {wolf.name}{partner ? ` + ${partner.name}` : ""} conceded
                  </button>
                  <button
                    onClick={() => update({ concededBy: "big" })}
                    style={{
                      padding: "8px 0", fontSize: 12, borderRadius: 8, cursor: "pointer", fontFamily: "inherit",
                      border: config.concededBy === "big" ? `1.5px solid ${sc.red}` : `1px solid ${sc.border}`,
                      background: config.concededBy === "big" ? sc.redLight : "#fff",
                      color: config.concededBy === "big" ? sc.red : sc.ink,
                    }}
                  >
                    Opponents conceded
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
